<!doctype html>
<html lang="es">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

	<title>Recuperación T1</title>



	<!-- Bootstrap core CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

	<link href="./resources/css/custom.css" rel="stylesheet">

</head>

<body>

	<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
		<h5 class="my-0 mr-md-auto font-weight-normal">Examen recuperación</h5>
	</div>

	<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
		<h1 class="display-4">Tabla de marcas</h1>
	</div>

	<div class="container-lg">
		<div class="row">
			<div class="form-container col-3">
				<div class="row">
					<div class="col-12">
						<form method="post">
							<label for="columna" class="form-label">Columna</label>
							<input type="text" class="form-control" id="columna" name="columna">
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<label for="fila" class="form-label">Fila</label>
						<input type="text" class="form-control" id="fila" name="fila">
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<button type="submit" class="btn btn-primary mt-3" name="marcar">Marcar</button>
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<button type="submit" class="btn btn-danger mt-3" name="limpiar">Limpiar</button>
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<button type="submit" class="btn btn-success mt-3" name="guardar">Guadar en B.D</button>
					</div>
				</div>
					</form>

			</div>
			<div id="board" class="col-9">
				<div id="messageArea"></div>
				<table>
					<tr>
						<th class="numbers"></th>
						<th class="numbers">1</th>
						<th class="numbers">2</th>
						<th class="numbers">3</th>
						<th class="numbers">4</th>
						<th class="numbers">5</th>
						<th class="numbers">6</th>
						<th class="numbers">7</th>
					</tr>

					<tr>
						<th class="letters">1</th>
						<td>
							<div id="00"></div>
						</td>
						<td>
							<div id="01"></div>
						</td>
						<td>
							<div id="02"></div>
						</td>
						<td>
							<div id="03"></div>
						</td>
						<td>
							<div id="04" class="miss"></div>
						</td>
						<td>
							<div id="05"></div>
						</td>
						<td>
							<div id="06"></div>
						</td>
					</tr>
					<tr>
						<th class="letters">2</th>
						<td>
							<div id="10"></div>
						</td>
						<td>
							<div id="11"></div>
						</td>
						<td>
							<div id="12"></div>
						</td>
						<td>
							<div id="13"></div>
						</td>
						<td>
							<div id="14"></div>
						</td>
						<td>
							<div id="15"></div>
						</td>
						<td>
							<div id="16"></div>
						</td>
					<tr>
						<th class="letters">3</th>
						<td>
							<div id="20"></div>
						</td>
						<td>
							<div id="21"></div>
						</td>
						<td>
							<div id="22"></div>
						</td>
						<td>
							<div id="23"></div>
						</td>
						<td>
							<div id="24"></div>
						</td>
						<td>
							<div id="25"></div>
						</td>
						<td>
							<div id="26"></div>
						</td>
					</tr>
					</tr>
					<tr>
						<th class="letters">4</th>
						<td>
							<div id="30"></div>
						</td>
						<td>
							<div id="31"></div>
						</td>
						<td>
							<div id="32"></div>
						</td>
						<td>
							<div id="33"></div>
						</td>
						<td>
							<div id="34"></div>
						</td>
						<td>
							<div id="35"></div>
						</td>
						<td>
							<div id="36"></div>
						</td>
					</tr>
					<tr>
						<th class="letters">5</td>
						<td>
							<div id="40"></div>
						</td>
						<td>
							<div id="41"></div>
						</td>
						<td>
							<div id="42"></div>
						</td>
						<td>
							<div id="43"></div>
						</td>
						<td>
							<div id="44"></div>
						</td>
						<td>
							<div id="45"></div>
						</td>
						<td>
							<div id="46"></div>
						</td>
					</tr>
					<tr>
						<th class="letters">6</td>
						<td>
							<div id="50"></div>
						</td>
						<td>
							<div id="51"></div>
						</td>
						<td>
							<div id="52"></div>
						</td>
						<td>
							<div id="53"></div>
						</td>
						<td>
							<div id="54"></div>
						</td>
						<td>
							<div id="55"></div>
						</td>
						<td>
							<div id="56"></div>
						</td>
					</tr>
					<tr>
						<th class="letters">7</td>
						<td>
							<div id="60"></div>
						</td>
						<td>
							<div id="61"></div>
						</td>
						<td>
							<div id="62"></div>
						</td>
						<td>
							<div id="63"></div>
						</td>
						<td>
							<div id="64"></div>
						</td>
						<td>
							<div id="65"></div>
						</td>
						<td>
							<div id="66"></div>
						</td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</body>
</html>