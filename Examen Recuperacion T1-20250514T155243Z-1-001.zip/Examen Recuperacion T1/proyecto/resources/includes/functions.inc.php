<?php

//TO DO: Rellena aquí todas las funciones que consideres. Trata de respetar la separación de la lógica de negocio y de presentación

function dump($vars){
	echo '<pre>'.print_r($vars,true).'</pre>';
}

function marcar() {

	$fila = $_POST['fila'];
	$columma = $_POST['columna'];

	$_SESSION['coordenadas'] = [$fila,$columma];



}

function limpiar() {
	session_unset();
	session_destroy();
}

function guardarBD() {

	dump($_SESSION['coordenadas']);
	$stmt = $db->prepare("INSERT INTO tablero marcas VALUES (:marcas)");
	$stmt->bindParam(':marcas',$, PDO::PARAM_STR);
	$stmt->execute();
}