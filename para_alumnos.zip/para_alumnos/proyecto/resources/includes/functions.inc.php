<?php

function getMovies($credenciales){
		
	//TO DO: Está función debe conectar a la base de datos, y traer todos las películas

	$dbname = trim($credenciales['database'],"'");

		$conn = new PDO("mysql:host={$credenciales['host']};dbname={$dbname}", trim($credenciales['username'],"'"), trim($credenciales['password'],"'"));
		$stmt = $conn->prepare("SELECT * FROM movies");
		$stmt->execute();

		$movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		return $movies;	

}
function getMovie($credenciales, $id){
	//TO DO: Está función debe conectar a la base de datos, y traer los datos de la película con $id
	return [];
}



function getMoviesMarkup($movies){

	$output = '<div  class="slick-multiItemSlider">';

	foreach ($movies as $movie) {
		
	    		$output .= '<div class="movie-item">
	    			<div class="mv-img">
	    				<a href="#"><img src="./resources/images/uploads/'.$movie['image_path'].'" alt="" width="285" height="437"></a>
	    			</div>
	    			<div class="title-in">
	    				<h6><a href="#">'.$movie['title'].'</a></h6>
	    				<p><i class="ion-android-star"></i><span>'.$movie['rating'].'</span> /10</p>
	    			</div>
	    		</div>
	    	</div>';
	}

	return $output;
}
function getMovieFormMarkup($movie){
	return '<form action="./update.php" method="post">
                    <input type="text" class="title" value="Skyfall: Quantum of Spectre">
					    <div class="movie-rate">
						    <div class="rate">
							    <i class="ion-android-star"></i>
							    <p><span>8.1</span><br>
								
							    </p>
						    </div>
					    </div>
					    <div class="movie-tabs">
					    	<div class="tabs">
					    		<ul class="tab-links tabs-mv">
					    			<li class="active"><a href="#overview">Description</a></li>
							    </ul>
						        <div class="tab-content">
						            <div id="overview" class="tab active">
						                <div class="row">
						             	    <div class="col-md-8 col-sm-12 col-xs-12">
						            		    <textarea class="description">Tony Stark creates the Ultron Program to protect the world, but when the peacekeeping program becomes hostile, The Avengers go into action to try and defeat a virtually impossible enemy together. Earth\'s mightiest heroes must come together once again to protect the world from global extinction.</textarea>
                                                <p><button class="btn">Actualizar</button></p>
						            	</div>
						            </div>
						        </div>
						    </div>
						</div>
					</div>
                </form>';
}
function dump($vars){
	echo '<pre>'.print_r($vars,true).'</pre>';
}